# KPP process anomaly detection — four-stage Python starter

This project implements all four requested stages. Run them separately or compare
all four on the same synthetic train/calibration/test runs. It is an offline
research starter for pressure, tow tension, speed and temperature, not a validated
AFP alarm system. No machine commands or parameter changes are issued.

## Files

- `detectors.py`: data checks, windows, direct/window z-score, Isolation Forest,
  threshold calibration, timestamp-based per-feature persistence and events.
- `lstm_detector.py`: PyTorch LSTM next-sample prediction and prediction-error scoring.
- `run.py`: fit/predict/demo commands, save/load models, result CSVs and plots.
- `demo_data.py`: independent synthetic normal train and calibration runs, and a
  test run with level, variability, relationship and temporal-order changes.
- `config.json`: signal names, setpoint mappings, sampling, windows and model settings.
- `test_pipeline.py`: data leakage/boundary/feature/persistence/sequence tests.
- `example_output/`: generated synthetic data, fitted models and example results.

## Install (Python 3.10+)

Use a virtual environment. These commands also work in Windows PowerShell after
selecting your Python environment:

```bash
python -m pip install -r requirements.txt
```

For Stage 4, install PyTorch as well:

```bash
python -m pip install -r requirements-lstm.txt
```

CPU execution is implemented and adequate for the small example. GPU setup is not
required. If your environment needs a particular PyTorch wheel, use the official
PyTorch installation selector. Package ranges describe the intended dependencies;
actual versions used here are in `TEST_REPORT.md` and each model metadata JSON.

## Quick start

Open a terminal in the extracted `kpp_all_stages` folder.

```bash
python run.py demo --stages 1 2 3 --out my_demo
python run.py demo --stages 4 --out my_lstm_demo
```

Or run all stages:

```bash
python run.py demo --out my_all_stages_demo
```

Inspect `stage1/test/scores.csv` and `scores.png`, then repeat for the other stages.
The included `example_output` contains a completed run so you can inspect the
formats without retraining. Demo labels are never given to the detectors.

## Stage 1: direct z-score + persistence

For each selected signal, fit the normal mean and sample standard deviation only
on training data. Compute z = (current value - normal mean) / normal standard
 deviation. Both unusually high and low values are candidates when abs(z)>3 by
 default. Confirmation requires that SAME feature to stay above threshold for
 the configured elapsed time. Alternating channels cannot accumulate persistence.
 The signed z-score is also exported so direction is visible.

This stage operates on raw measurements. If targets vary substantially, a fixed
level baseline may generate expected flags. Use operating-condition-specific
models, or the tracking-error features in Stage 2.

## Stage 2: z-scores on window features

For every signal calculate trailing window mean and sample standard deviation.
For each signal with a configured setpoint, also calculate signed mean error
(bias) and RMSE. Fit a separate normal mean and standard deviation for each
FEATURE. A window RMSE is compared with normal window RMSE values, never with the
raw signal's standard deviation. Default window: 5 s, hop: 0.5 s at 10 Hz.

The full window is required. Missing samples invalidate affected feature windows;
initial warm-up rows remain unavailable. Windows never cross segments. A nominal
5 s window at 10 Hz contains 50 samples, whose first/last timestamps span 4.9 s.
Both tails are tested; unusually LOW variability can indicate a frozen sensor,
but validate whether two-sided checks are meaningful for each feature.

## Stage 3: Isolation Forest on joint window features

Reuse the same features as Stage 2. Fit a StandardScaler and IsolationForest on
complete normal training windows. Scaling is retained as a common preparation
step; Isolation Forest does not inherently require standardization. The score is
`-model.score_samples(X)`, so larger means more anomalous. Use the 99th percentile
of separate NORMAL calibration scores as the default candidate threshold.
The sklearn `contamination` prediction threshold is not used.

This stage returns one joint anomaly score; it does not identify a causal KPP.
It may detect unusual feature combinations, but detecting every correlation
change is not guaranteed. Redundant features and many similar channels can alter
its sensitivity; validate your selected feature set.

## Stage 4: LSTM prediction error

Fit input normalization on normal TRAINING data only. Given the previous 30
samples (3 s at 10 Hz), predict the next values of all selected signals.
The prediction target is not included in its input sequence. Use a unidirectional
LSTM with 24 hidden units plus a linear output layer, trained for a fixed 12
epochs with Adam and gradient clipping. Batch shuffling occurs only within the
already separated training split; sequence order inside each batch is retained.

The anomaly score is the mean squared prediction error across channels in
training-standardized units. Calibrate the threshold using the 99th percentile
of prediction-error scores on separate NORMAL calibration runs. Apply the same
persistence rule. Physical-unit predictions and per-channel standardized squared
errors are exported for interpretation. No online training occurs.

Sequences never cross segment boundaries, missing values, or split boundaries.
Initial sequence warm-up and incomplete sequences are marked unavailable.
A fixed epoch count keeps threshold-calibration data out of model selection. If
you tune epochs, architecture or early stopping, reserve ADDITIONAL model-selection
runs rather than repeatedly optimizing on calibration or final test data.

This is prediction-error detection, not an LSTM autoencoder. An autoencoder could
replace this stage later. LSTM is not guaranteed to outperform z-score or Forest:
persistent faults can enter the input history and become predictable; brief large
errors can fail the persistence rule. Mean channel error can dilute a single
channel fault. Keep engineering limits and useful simpler detectors alongside it.

## Input contract for real data

Example columns (one row per timestamp):

```csv
timestamp,segment_id,tension_N,pressure_bar,speed_mm_s,temperature_C,tension_setpoint_N,pressure_setpoint_bar
2026-01-01T10:00:00.000Z,run01_laying01,50.2,5.02,100.1,60.2,50.0,5.0
2026-01-01T10:00:00.100Z,run01_laying01,49.9,4.99,100.2,60.1,50.0,5.0
```

- Change `signals` in config.json to your actual measured column names.
- Change `setpoints` to mappings from measurement column to target column.
  Use `{}` if targets are unavailable; only mean/std features will be produced.
- One model/config represents ONE consistent operating condition. Train separate
  models for different recipes, materials or modes. No automatic context router.
- Each segment ID is globally unique and identifies one uninterrupted interval.
  Separate laying intervals around a stop; do not concatenate them as continuous.
- ISO timestamps are required; UTC is recommended. Naive timestamps are treated
  as UTC, so convert local timestamps explicitly before use.
- Sample periods must match the configuration within 1% jitter; gaps and duplicates
  are rejected. Resample upstream where appropriate or split at gaps first.
- Numeric NaNs are preserved; infinity and malformed strings fail explicitly.
  There is no automatic interpolation, outlier removal or normalization refitting.
- Stages 1–2 can identify an anomaly from an available feature even if another is
  invalid. Otherwise partial validity yields `insufficient_data`. Stages 3–4 need
  complete feature vectors/sequences and produce no score when incomplete.
- Constant/near-constant z-score baselines fail with an explanatory error. Use
  an engineering tolerance detector for those variables or remove that feature;
  dividing by an arbitrary epsilon would create misleading scores.
- At least 30 usable baseline/calibration rows or sequences is a code guard,
  NOT evidence that the data amount is statistically adequate. Use representative
  normal runs spanning expected variation, and consider temporal dependence.

## Fit, save and score real data

Prepare `normal_train.csv`, `normal_calibration.csv`, and `test.csv` using different
complete runs. Do not randomly split overlapping windows. Training/calibration
segment IDs and timestamp ranges must not overlap; use actual absolute times.
Final test runs must also be independently held out; this is the user's
responsibility when calling `predict`, which also permits replay for debugging.

```bash
python run.py fit --stage 1 --train normal_train.csv --calibration normal_calibration.csv --config config.json --out models/stage1
python run.py predict --model models/stage1/model.joblib --data test.csv --out results/stage1 --plot
```

Repeat with `--stage 2`, `--stage 3`, or `--stage 4`, changing output directories.
Stages 1–2 use the configured z threshold; their calibration results are exported
for review. Stages 3–4 derive their thresholds from normal calibration scores.
Store model metadata with the model. Only load your own trusted joblib files:
joblib uses pickle and loading untrusted artifacts can execute code.
Keep these Python modules available when loading models. Regenerate bundled demo
models if your scikit-learn or other library versions differ from the metadata.

## Configuration explained

| Setting | Meaning |
|---|---|
| sample_period | Seconds between raw samples |
| window_seconds | History used for Stage 2/3 feature calculation |
| hop_seconds | Stage 2/3 reporting interval |
| z_threshold | Absolute z cutoff for Stages 1/2 |
| persistence_seconds | Continuous same-feature exceedance time before confirmation |
| calibration_quantile | Normal calibration score percentile for Stages 3/4 |
| sequence_length | Number of preceding raw samples given to the LSTM |
| epochs / hidden_size | Fixed LSTM training configuration |

Window size/hop must be integer sample-period multiples. A faster update interval
does not remove window-induced detection delay. Default settings demonstrate the
workflow; choose them using process dynamics and held-out validation evidence.

## Output meaning

Each stage saves `scores.csv`, `events.csv` and `summary.json`. Plots are produced
by demo or predict --plot. `model.joblib` stores fitted state; `model_metadata.json`
stores the configuration, threshold, provenance IDs, package versions, and LSTM
training loss where applicable.

- `candidate`: score exceeds threshold at this reporting timestamp.
- `confirmed`: that feature's exceedance has persisted long enough.
- `normal`: all required feature scores available, none above threshold.
- `insufficient_data`: warm-up or invalid features prevent a normal conclusion.
- `events.csv`: feature, candidate start, confirmation time, last candidate,
  observed first-to-last span and peak score. No hysteresis in this starter.

The event span is observed detector evidence, not the physical fault duration.
Events reaching the data end have an unknown recovery time. Multiple features can
produce overlapping events for one physical occurrence; do not add their durations
or count them as independent process failures. Merge event intervals for system
level reporting. Gaps/missing values/segment boundaries reset persistence.

## Validation and comparison

Run `python -m unittest -v test_pipeline.py` for implementation checks.
Demo additionally tests model serialization by comparing predictions before and
after reload for every selected stage. TEST_REPORT.md records the actual run.

Do not select a winner by number of detections. For actual labelled runs, define
an event-matching policy first, then compare event recall, false events per hour,
detection delay, data coverage, and interpretation effort. A detection after an
event ends is late; report that rather than silently expanding every event label.
Raw and window stages have different cadences and delays. Overlapping windows
are dependent, and 99th-percentile calibration does not guarantee 1% future false
alarms. More features also increase the chance of a z-score exceedance.

Synthetic labels describe injected intervals only. The example deliberately
includes behaviours that some stages may miss; it is not an accuracy benchmark.
Retain a simple next-value-equals-current-value prediction baseline when assessing
whether the LSTM adds useful temporal modelling on your real data.

## Sources

- scikit-learn IsolationForest: https://scikit-learn.org/stable/modules/generated/sklearn.ensemble.IsolationForest.html
- PyTorch LSTM: https://docs.pytorch.org/docs/stable/generated/torch.nn.LSTM.html
