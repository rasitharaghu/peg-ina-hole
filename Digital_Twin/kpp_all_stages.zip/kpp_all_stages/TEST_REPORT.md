# Verification report

Executed all four stages on independent synthetic train/calibration/test runs.

- Seven implementation tests passed.
- All four models trained and scored successfully.
- Predictions matched exactly before and after model serialization for every stage.
- Stage 4 also passed a separate CLI predict invocation and CSV comparison.
- Normalization/model fitting used training data only.
- Isolation Forest and LSTM thresholds used independent normal calibration data.
- Test labels were not used for fitting, scoring or thresholds.

These checks establish that the implementation runs and satisfies tested contracts.
They do not establish detection accuracy on AFP process data.

## Executed versions

Python: 3.12.14

- numpy: 2.3.5
- pandas: 2.2.3
- scikit-learn: 1.8.0
- torch: 2.14.1+cpu
- joblib: 1.5.3

LSTM training MSE (standardized units): first epoch 0.7564095470221234, last epoch 0.111459276256179.
