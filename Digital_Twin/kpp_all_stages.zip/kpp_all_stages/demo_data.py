"""Synthetic independent runs, never a claim of AFP detection performance."""
from pathlib import Path
import numpy as np
import pandas as pd


def generate(folder):
    folder = Path(folder); folder.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(17)
    def run(sid, day, anomalies=False):
        n = 2400; t = np.arange(n)/10
        phase = rng.uniform(0, 2*np.pi)
        speed = 100 + 8*np.sin(0.12*t + phase) + rng.normal(0,0.4,n)
        tt = 50 + 0.08*(speed-100); pt = 5 + 0.015*(speed-100)
        d = pd.DataFrame({'timestamp':pd.date_range(f'2026-01-{day:02d}',periods=n,freq='100ms',tz='UTC'),
            'segment_id':sid,'tension_N':tt+rng.normal(0,0.25,n),
            'pressure_bar':pt+rng.normal(0,0.035,n),'speed_mm_s':speed,
            'temperature_C':60+0.15*(speed-100)+rng.normal(0,0.15,n),
            'tension_setpoint_N':tt,'pressure_setpoint_bar':pt,'label':0,'event_type':'normal'})
        if anomalies:
            d.loc[400:599,'tension_N'] += 5
            d.loc[400:599,['label','event_type']] = [1,'tension_shift']
            d.loc[850:1099,'pressure_bar'] += rng.normal(0,0.5,250)
            d.loc[850:1099,['label','event_type']] = [1,'pressure_variability']
            d.loc[1350:1649,'temperature_C'] = 60-0.15*(speed[1350:1650]-100)+rng.normal(0,0.15,300)
            d.loc[1350:1649,['label','event_type']] = [1,'relationship_change']
            d.loc[1900:2149,'tension_N'] = rng.permutation(d.loc[1900:2149,'tension_N'].to_numpy())
            d.loc[1900:2149,['label','event_type']] = [1,'temporal_shuffle']
        return d
    files={'train.csv':pd.concat([run('train01',1),run('train02',2)],ignore_index=True),
           'calibration.csv':pd.concat([run('cal01',3),run('cal02',4)],ignore_index=True),
           'test.csv':run('test01',5,True)}
    for name,d in files.items(): d.to_csv(folder/name,index=False)
    return folder
