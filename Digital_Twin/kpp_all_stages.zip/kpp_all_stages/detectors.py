"""Shared preparation and four offline KPP anomaly detectors."""
from dataclasses import dataclass
import numpy as np
import pandas as pd
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import StandardScaler


@dataclass
class Config:
    signals: list
    setpoints: dict
    sample_period: float = 0.1
    window_seconds: float = 10.0
    hop_seconds: float = 1.0
    z_threshold: float = 3.0
    persistence_seconds: float = 1.0
    calibration_quantile: float = 0.99
    sequence_length: int = 30
    hidden_size: int = 24
    epochs: int = 12
    batch_size: int = 128
    learning_rate: float = 0.001
    seed: int = 42

    def validate(self):
        if not self.signals or len(set(self.signals)) != len(self.signals):
            raise ValueError('signals must be a nonempty unique list')
        if not set(self.setpoints).issubset(self.signals):
            raise ValueError('setpoint mapping keys must be monitored signals')
        for x in [self.sample_period, self.window_seconds, self.hop_seconds,
                  self.z_threshold, self.learning_rate]:
            if not np.isfinite(x) or x <= 0:
                raise ValueError('Sampling/window/threshold/rate parameters must be positive')
        if not np.isfinite(self.persistence_seconds) or self.persistence_seconds < 0:
            raise ValueError('Persistence must be finite and nonnegative')
        if not 0 < self.calibration_quantile < 1:
            raise ValueError('Calibration quantile must lie strictly between 0 and 1')
        for x in [self.sequence_length, self.hidden_size, self.epochs, self.batch_size]:
            if isinstance(x, bool) or not isinstance(x, int) or x < 1:
                raise ValueError('Sequence/model/batch/epoch settings must be positive integers')
        self.samples(self.window_seconds, minimum=2)
        self.samples(self.hop_seconds)
        return self

    def samples(self, seconds, minimum=1):
        n = round(seconds / self.sample_period)
        if n < minimum or not np.isclose(n * self.sample_period, seconds):
            raise ValueError('Window and hop must be integer multiples of sample_period')
        return n


def prepare(data, cfg):
    """One condition per model; segment_id identifies each uninterrupted interval.

    Missing numeric values are preserved. Invalid timestamps, infinities,
    duplicate times or gaps beyond 1% sampling jitter fail explicitly.
    """
    cfg.validate()
    needed = ['timestamp', 'segment_id', *cfg.signals, *cfg.setpoints.values()]
    if data.empty or not set(needed).issubset(data):
        raise ValueError(f'Input must be nonempty and contain {sorted(set(needed))}')
    d = data.copy()
    d['timestamp'] = pd.to_datetime(d.timestamp, format='ISO8601', utc=True, errors='raise')
    if d[['timestamp', 'segment_id']].isna().any().any():
        raise ValueError('Missing timestamp or segment_id')
    d['segment_id'] = d.segment_id.astype(str)
    numeric = list(dict.fromkeys([*cfg.signals, *cfg.setpoints.values()]))
    for name in numeric:
        d[name] = pd.to_numeric(d[name], errors='raise')
        if np.isinf(d[name].to_numpy(float)).any():
            raise ValueError(f'Infinite values in {name}; mark invalid samples as NaN')
    parts = []
    for sid, g in d.groupby('segment_id', sort=False):
        g = g.sort_values('timestamp').reset_index(drop=True)
        dt = g.timestamp.diff().dt.total_seconds().iloc[1:]
        if not np.allclose(dt, cfg.sample_period, rtol=0.01, atol=1e-6):
            raise ValueError(f'{sid}: duplicates, irregular sampling or gaps; split at gaps first')
        parts.append(g)
    return pd.concat(parts, ignore_index=True)


def ensure_disjoint(*datasets):
    """Unique segment identifiers across splits; also reject overlapping times.

    This intentionally requires chronological, nonoverlapping recording ranges
    across splits. Do not reset timestamps to zero for each split.
    """
    for i, a in enumerate(datasets):
        for b in datasets[i + 1:]:
            if set(a.segment_id) & set(b.segment_id):
                raise ValueError('Data splits share segment IDs; split by complete runs')
            if not (a.timestamp.max() < b.timestamp.min() or b.timestamp.max() < a.timestamp.min()):
                raise ValueError('Data split timestamp ranges overlap')


def window_features(d, cfg):
    """Trailing, causal windows; retain warm-up/invalid rows at hop cadence."""
    n, hop = cfg.samples(cfg.window_seconds, 2), cfg.samples(cfg.hop_seconds)
    parts = []
    for _, g in d.groupby('segment_id', sort=False):
        g = g.reset_index(drop=True)
        f = g[['timestamp', 'segment_id']].copy()
        for s in cfg.signals:
            r = g[s].rolling(n, min_periods=n)
            f[s + '__mean'] = r.mean()
            f[s + '__std'] = r.std(ddof=1)
            if s in cfg.setpoints:
                error = g[s] - g[cfg.setpoints[s]]
                f[s + '__bias'] = error.rolling(n, min_periods=n).mean()
                f[s + '__rmse'] = np.sqrt(error.pow(2).rolling(n, min_periods=n).mean())
        # First full window is always included, then every hop.
        parts.append(f.iloc[(n - 1) % hop::hop])
    return pd.concat(parts, ignore_index=True)


def feature_names(f):
    return [c for c in f if c not in ['timestamp', 'segment_id']]


def normal_stats(x, names):
    result = {}
    for name in names:
        v = x[name].dropna().to_numpy(float)
        if len(v) < 30 or not np.isfinite(v).all():
            raise ValueError(f'{name}: need >=30 finite normal baseline values')
        mu, sd = v.mean(), v.std(ddof=1)
        if sd <= 1e-12 * max(1., abs(mu)):
            raise ValueError(f'{name}: near-constant baseline; use engineering tolerance or remove feature')
        result[name] = (float(mu), float(sd))
    return result


class ZScore:
    def fit(self, f):
        self.stats = normal_stats(f, feature_names(f))
        return self

    def score(self, f):
        return pd.DataFrame({name: (f[name] - mu) / sd
                             for name, (mu, sd) in self.stats.items()}, index=f.index)


class Forest:
    """Larger score means more anomalous; negate sklearn score_samples."""
    def fit(self, f, cfg):
        self.names = feature_names(f)
        x = f[self.names].to_numpy(float)
        valid = np.isfinite(x).all(axis=1)
        if valid.sum() < 30:
            raise ValueError('Isolation Forest needs >=30 complete normal windows')
        self.scaler = StandardScaler().fit(x[valid])
        self.model = IsolationForest(n_estimators=200, random_state=cfg.seed,
                                     contamination='auto', n_jobs=1)
        self.model.fit(self.scaler.transform(x[valid]))
        return self

    def score(self, f):
        x = f[self.names].to_numpy(float)
        valid = np.isfinite(x).all(axis=1)
        out = np.full(len(f), np.nan)
        if valid.any():
            out[valid] = -self.model.score_samples(self.scaler.transform(x[valid]))
        return pd.DataFrame({'joint_score': out}, index=f.index)


def calibrate(scores, quantile):
    x = np.asarray(scores).reshape(-1)
    x = x[np.isfinite(x)]
    if len(x) < 30:
        raise ValueError('Need >=30 valid normal calibration scores')
    return float(np.quantile(x, quantile))


def decide(meta, evidence, thresholds, persistence_seconds, expected_step):
    """Threshold each channel separately, then OR confirmed results.

    evidence must be nonnegative: absolute z, forest score or LSTM MSE.
    A gap, invalid value or segment boundary resets persistence. No hysteresis.
    """
    out = meta[['timestamp', 'segment_id']].reset_index(drop=True).copy()
    evidence = evidence.reset_index(drop=True)
    if len(out) != len(evidence):
        raise ValueError('Metadata/evidence length mismatch')
    candidate_cols, confirmed_cols = [], []
    events = []
    for name in evidence:
        values = evidence[name].to_numpy(float)
        candidate = np.isfinite(values) & (values > thresholds[name])
        confirmed = np.zeros(len(out), dtype=bool)
        for sid, g in out.groupby('segment_id', sort=False):
            streak, previous = [], None
            def finish():
                if streak:
                    active = [i for i in streak if confirmed[i]]
                    if active:
                        first, last = streak[0], streak[-1]
                        events.append(dict(segment_id=sid, feature=name,
                            candidate_start=out.at[first, 'timestamp'],
                            confirmed_at=out.at[active[0], 'timestamp'],
                            last_candidate=out.at[last, 'timestamp'],
                            observed_span_seconds=(out.at[last, 'timestamp'] - out.at[first, 'timestamp']).total_seconds(),
                            peak_score=float(np.max(values[streak]))))
            for i in g.index:
                now = out.at[i, 'timestamp']
                gap = previous is not None and (now - previous).total_seconds() > expected_step * 1.02
                if gap or not candidate[i]:
                    finish(); streak = []
                if candidate[i]:
                    streak.append(i)
                    confirmed[i] = (now - out.at[streak[0], 'timestamp']).total_seconds() >= persistence_seconds
                previous = now
            finish()
        out[name + '__score'] = values
        out[name + '__candidate'] = candidate
        out[name + '__confirmed'] = confirmed
        candidate_cols.append(candidate); confirmed_cols.append(confirmed)
    out['valid'] = np.isfinite(evidence.to_numpy(float)).all(axis=1)
    out['any_candidate'] = np.logical_or.reduce(candidate_cols)
    out['any_confirmed'] = np.logical_or.reduce(confirmed_cols)
    out['status'] = np.where(out.any_confirmed, 'anomaly',
        np.where(~out.valid, 'insufficient_data', np.where(out.any_candidate, 'candidate', 'normal')))
    event_cols = ['segment_id', 'feature', 'candidate_start', 'confirmed_at',
                  'last_candidate', 'observed_span_seconds', 'peak_score']
    return out, pd.DataFrame(events, columns=event_cols)
