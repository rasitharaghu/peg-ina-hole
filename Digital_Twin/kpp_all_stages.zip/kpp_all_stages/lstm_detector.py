"""Stage 4: next-sample prediction using only preceding observations."""
import numpy as np
import pandas as pd
from detectors import normal_stats


def torch_modules():
    try:
        import torch
    except ImportError as exc:
        raise RuntimeError('Stage 4 requires PyTorch: pip install -r requirements-lstm.txt') from exc
    return torch, torch.nn


def build_network(input_size, hidden_size):
    torch, nn = torch_modules()
    class Predictor(nn.Module):
        def __init__(self):
            super().__init__()
            self.lstm = nn.LSTM(input_size, hidden_size, batch_first=True)
            self.head = nn.Linear(hidden_size, input_size)
        def forward(self, x):
            y, _ = self.lstm(x)
            return self.head(y[:, -1, :])
    return Predictor()


def sequences(d, signals, mu, sd, length):
    """Target at t, inputs [t-length, ..., t-1]; never cross segment/NaN."""
    xs, ys, indices = [], [], []
    for _, g in d.groupby('segment_id', sort=False):
        values = (g[signals].to_numpy(float) - mu) / sd
        ix = g.index.to_numpy()
        for t in range(length, len(g)):
            block = values[t-length:t+1]
            if np.isfinite(block).all():
                xs.append(block[:-1]); ys.append(block[-1]); indices.append(ix[t])
    shape = (0, length, len(signals))
    x = np.asarray(xs, dtype=np.float32) if xs else np.empty(shape, np.float32)
    y = np.asarray(ys, dtype=np.float32) if ys else np.empty((0, len(signals)), np.float32)
    return x, y, np.asarray(indices, dtype=int)


class LSTMDetector:
    def fit(self, train, cfg):
        torch, nn = torch_modules()
        torch.manual_seed(cfg.seed)
        torch.set_num_threads(1)
        self.signals = cfg.signals
        stats = normal_stats(train, self.signals)
        self.mu = np.array([stats[s][0] for s in self.signals])
        self.sd = np.array([stats[s][1] for s in self.signals])
        self.length, self.hidden_size = cfg.sequence_length, cfg.hidden_size
        x, y, _ = sequences(train, self.signals, self.mu, self.sd, self.length)
        if len(x) < 30:
            raise ValueError('Need >=30 complete normal training sequences')
        net = build_network(len(self.signals), self.hidden_size)
        opt = torch.optim.Adam(net.parameters(), lr=cfg.learning_rate)
        ds = torch.utils.data.TensorDataset(torch.from_numpy(x), torch.from_numpy(y))
        generator = torch.Generator().manual_seed(cfg.seed)
        batches = torch.utils.data.DataLoader(ds, batch_size=cfg.batch_size,
                                             shuffle=True, generator=generator)
        self.history = []
        # Fixed epoch count. Calibration data is NOT used for weight fitting,
        # epoch selection or normalization; reserve extra runs for model tuning.
        for epoch in range(cfg.epochs):
            net.train(); total = 0.
            for xb, yb in batches:
                opt.zero_grad()
                loss = nn.functional.mse_loss(net(xb), yb)
                loss.backward()
                nn.utils.clip_grad_norm_(net.parameters(), 1.)
                opt.step(); total += loss.item() * len(xb)
            self.history.append(total / len(ds))
        # Store portable numpy weights, avoiding pickled local torch classes.
        self.weights = {k: v.detach().cpu().numpy().copy() for k, v in net.state_dict().items()}
        return self

    def score(self, d):
        torch, _ = torch_modules()
        torch.set_num_threads(1)
        x, y, ix = sequences(d, self.signals, self.mu, self.sd, self.length)
        net = build_network(len(self.signals), self.hidden_size)
        net.load_state_dict({k: torch.from_numpy(v) for k, v in self.weights.items()})
        net.eval()
        score = np.full(len(d), np.nan)
        details = pd.DataFrame(index=d.index)
        pred = np.full((len(d), len(self.signals)), np.nan)
        squared = np.full_like(pred, np.nan)
        with torch.no_grad():
            for start in range(0, len(x), 512):
                stop = start + 512
                predicted = net(torch.from_numpy(x[start:stop])).numpy()
                errors = (predicted - y[start:stop]) ** 2
                rows = ix[start:stop]
                score[rows] = errors.mean(axis=1)
                squared[rows] = errors
                pred[rows] = predicted * self.sd + self.mu
        for j, signal in enumerate(self.signals):
            details[signal + '__prediction'] = pred[:, j]
            details[signal + '__squared_standardized_error'] = squared[:, j]
        return pd.DataFrame({'prediction_mse': score}, index=d.index), details
