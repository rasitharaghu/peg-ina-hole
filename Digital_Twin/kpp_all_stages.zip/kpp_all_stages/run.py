"""Run demo, fit one detector, or predict with a saved model. See README.md."""
import argparse
from dataclasses import asdict
import importlib.metadata
import json
from pathlib import Path
import joblib
import pandas as pd
from detectors import Config, prepare, ensure_disjoint, window_features, ZScore, Forest, calibrate, decide
from demo_data import generate


def versions():
    result={}
    for x in ['numpy','pandas','scikit-learn','torch','joblib']:
        try: result[x]=importlib.metadata.version(x)
        except importlib.metadata.PackageNotFoundError: result[x]='not installed'
    return result


def fit_stage(stage,train,calibration,cfg):
    if stage==1:
        model=ZScore().fit(train[['timestamp','segment_id',*cfg.signals]])
        thresholds={k:cfg.z_threshold for k in model.stats}
    elif stage==2:
        model=ZScore().fit(window_features(train,cfg))
        thresholds={k:cfg.z_threshold for k in model.stats}
    elif stage==3:
        model=Forest().fit(window_features(train,cfg),cfg)
        thresholds={'joint_score':calibrate(model.score(window_features(calibration,cfg)),cfg.calibration_quantile)}
    elif stage==4:
        from lstm_detector import LSTMDetector
        model=LSTMDetector().fit(train,cfg)
        values,_=model.score(calibration)
        thresholds={'prediction_mse':calibrate(values,cfg.calibration_quantile)}
    else: raise ValueError('Stage must be 1, 2, 3 or 4')
    return dict(schema_version=1,stage=stage,config=asdict(cfg),model=model,thresholds=thresholds,
        versions=versions(),training_ids=train.segment_id.unique().tolist(),
        calibration_ids=calibration.segment_id.unique().tolist())


def infer(bundle,data):
    cfg=Config(**bundle['config']).validate()
    stage,model=bundle['stage'],bundle['model']
    if stage in [1,2]:
        f=data[['timestamp','segment_id',*cfg.signals]] if stage==1 else window_features(data,cfg)
        signed=model.score(f); evidence=signed.abs()
        details=f.drop(columns=['timestamp','segment_id']).copy()
        for c in signed: details[c+'__signed_z']=signed[c]
    elif stage==3:
        f=window_features(data,cfg); evidence=model.score(f)
        details=f.drop(columns=['timestamp','segment_id']).copy()
    else:
        f=data; evidence,details=model.score(data)
    step=cfg.hop_seconds if stage in [2,3] else cfg.sample_period
    scores,events=decide(f,evidence,bundle['thresholds'],cfg.persistence_seconds,step)
    return pd.concat([scores,details.reset_index(drop=True)],axis=1),events


def save_results(bundle,data,folder,plot=False):
    folder=Path(folder); folder.mkdir(parents=True,exist_ok=True)
    scores,events=infer(bundle,data)
    scores.to_csv(folder/'scores.csv',index=False); events.to_csv(folder/'events.csv',index=False)
    report={'rows':len(scores),'valid_rows':int(scores.valid.sum()),
        'candidate_rows':int(scores.any_candidate.sum()),'confirmed_rows':int(scores.any_confirmed.sum()),
        'feature_events':len(events),'note':'Counts are not accuracy metrics; stages use different output cadences.'}
    (folder/'summary.json').write_text(json.dumps(report,indent=2))
    if plot:
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
        names=[c for c in scores if c.endswith('__score')]
        fig,axes=plt.subplots(len(names),1,figsize=(12,max(3,2.2*len(names))),squeeze=False)
        for ax,c in zip(axes[:,0],names):
            feature=c[:-7]
            for _,g in scores.groupby('segment_id',sort=False):
                ax.plot(g.timestamp,g[c],lw=0.7)
                hit=g[feature+'__confirmed']
                ax.scatter(g.loc[hit,'timestamp'],g.loc[hit,c],s=6,color='red')
            ax.axhline(bundle['thresholds'][feature],color='orange',ls='--')
            ax.set_ylabel(feature,fontsize=8); ax.grid(alpha=0.2)
        fig.suptitle(f"Stage {bundle['stage']} — score, threshold and confirmed points")
        fig.autofmt_xdate(); fig.tight_layout(); fig.savefig(folder/'scores.png',dpi=120); plt.close(fig)
    return report


def train_and_save(stage,train,calibration,cfg,folder):
    folder=Path(folder); folder.mkdir(parents=True,exist_ok=True)
    bundle=fit_stage(stage,train,calibration,cfg)
    joblib.dump(bundle,folder/'model.joblib')
    metadata={k:v for k,v in bundle.items() if k!='model'}
    if stage in [1,2]: metadata['normal_mean_std']=bundle['model'].stats
    if stage==4: metadata['training_mse_by_epoch']=bundle['model'].history
    (folder/'model_metadata.json').write_text(json.dumps(metadata,indent=2))
    save_results(bundle,calibration,folder/'calibration')
    return bundle


def main():
    p=argparse.ArgumentParser(description=__doc__)
    sub=p.add_subparsers(dest='command',required=True)
    demo=sub.add_parser('demo'); demo.add_argument('--stages',nargs='+',type=int,choices=[1,2,3,4],default=[1,2,3,4])
    demo.add_argument('--out',default='demo_output')
    demo.add_argument('--config',default=str(Path(__file__).with_name('config.json')))
    fit=sub.add_parser('fit'); fit.add_argument('--stage',type=int,choices=[1,2,3,4],required=True)
    fit.add_argument('--train',required=True); fit.add_argument('--calibration',required=True)
    fit.add_argument('--config',required=True); fit.add_argument('--out',required=True)
    pred=sub.add_parser('predict'); pred.add_argument('--model',required=True)
    pred.add_argument('--data',required=True); pred.add_argument('--out',required=True)
    pred.add_argument('--plot',action='store_true')
    args=p.parse_args()
    if args.command=='predict':
        # Load only trusted artifacts: joblib/pickle can execute code.
        bundle=joblib.load(args.model)
        data=prepare(pd.read_csv(args.data),Config(**bundle['config']))
        print(json.dumps(save_results(bundle,data,args.out,args.plot),indent=2)); return
    cfg=Config(**json.loads(Path(args.config).read_text())).validate()
    if args.command=='fit':
        train=prepare(pd.read_csv(args.train),cfg); cal=prepare(pd.read_csv(args.calibration),cfg)
        ensure_disjoint(train,cal); train_and_save(args.stage,train,cal,cfg,args.out)
        print(f'Stage {args.stage} saved in {args.out}'); return
    folder=Path(args.out); data_folder=generate(folder/'synthetic_data')
    train,cal,test=[prepare(pd.read_csv(data_folder/name),cfg) for name in ['train.csv','calibration.csv','test.csv']]
    ensure_disjoint(train,cal,test); reports={}
    for stage in args.stages:
        print(f'Fitting stage {stage}...',flush=True)
        target=folder/f'stage{stage}'
        bundle=train_and_save(stage,train,cal,cfg,target)
        reports[f'stage{stage}']=save_results(bundle,test,target/'test',plot=True)
        reloaded=joblib.load(target/'model.joblib')
        a,_=infer(bundle,test); b,_=infer(reloaded,test)
        pd.testing.assert_frame_equal(a,b)
    (folder/'demo_summary.json').write_text(json.dumps(reports,indent=2))
    print(json.dumps(reports,indent=2)); print('Synthetic example only; no real AFP performance claim.')


if __name__=='__main__': main()
