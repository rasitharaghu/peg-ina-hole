import unittest
import numpy as np
import pandas as pd
from detectors import Config,prepare,ensure_disjoint,window_features,ZScore,decide,calibrate
from lstm_detector import sequences


def data(n=100,sid='a',day=1):
    return pd.DataFrame({'timestamp':pd.date_range(f'2026-01-{day:02d}',periods=n,freq='100ms',tz='UTC'),
        'segment_id':sid,'x':np.tile([0.,2.],(n+1)//2)[:n],'target':1.})


class PipelineTests(unittest.TestCase):
    def setUp(self):
        self.cfg=Config(signals=['x'],setpoints={'x':'target'},window_seconds=0.4,hop_seconds=0.1)
    def test_known_z_frozen_reference(self):
        f=data()[['timestamp','segment_id','x']]; m=ZScore().fit(f); ref=m.stats.copy(); f['x']=10
        self.assertAlmostEqual(m.score(f).x.iloc[0],9/np.sqrt(100/99)); self.assertEqual(ref,m.stats)
    def test_tracking_windows_no_future(self):
        d=prepare(data(),self.cfg); f=window_features(d,self.cfg)
        self.assertTrue(pd.isna(f.x__mean.iloc[0])); self.assertAlmostEqual(f.x__mean.iloc[3],1)
        self.assertAlmostEqual(f.x__rmse.iloc[3],1); self.assertAlmostEqual(f.x__bias.iloc[3],0)
        d.loc[50:,'x']=900
        pd.testing.assert_frame_equal(f.iloc[:50],window_features(d,self.cfg).iloc[:50])
    def test_missing_boundaries(self):
        d=pd.concat([data(10),data(10,'b',2)],ignore_index=True); d.loc[5,'x']=np.nan
        f=window_features(prepare(d,self.cfg),self.cfg)
        self.assertTrue(f.x__mean.iloc[5:9].isna().all()); self.assertTrue(f.x__mean.iloc[10:13].isna().all())
    def test_gap_duplicate_split_leakage(self):
        with self.assertRaises(ValueError): prepare(data().drop(index=5),self.cfg)
        d=data(); d.loc[1,'timestamp']=d.loc[0,'timestamp']
        with self.assertRaises(ValueError): prepare(d,self.cfg)
        with self.assertRaises(ValueError): ensure_disjoint(data(),data())
        ensure_disjoint(data(),data(sid='b',day=2))
    def test_per_feature_persistence_invalid_reset(self):
        meta=data(8)[['timestamp','segment_id']]
        ev=pd.DataFrame({'a':[4,4,np.nan,4,4,4,0,0],'b':[0,0,4,0,0,0,0,0]})
        scores,events=decide(meta,ev,{'a':3,'b':3},0.2,0.1)
        self.assertFalse(scores.any_confirmed.iloc[:5].any()); self.assertTrue(scores.any_confirmed.iloc[5])
        self.assertEqual(scores.status.iloc[2],'insufficient_data'); self.assertEqual(len(events),1)
        self.assertEqual(events.feature.iloc[0],'a')
    def test_sequence_target_alignment_nan(self):
        d=pd.concat([data(8),data(8,'b',2)],ignore_index=True); d['x']=np.arange(16,dtype=float)
        x,y,ix=sequences(d,['x'],np.array([0]),np.array([1]),3)
        self.assertEqual(ix.tolist(),[3,4,5,6,7,11,12,13,14,15])
        np.testing.assert_array_equal(x[0,:,0],[0,1,2]); self.assertEqual(y[0,0],3)
        d.loc[4,'x']=np.nan
        _,_,ix=sequences(d,['x'],np.array([0]),np.array([1]),3)
        self.assertFalse(any(i in ix for i in [4,5,6,7]))
    def test_calibration_constant_guard(self):
        self.assertAlmostEqual(calibrate(np.arange(100),0.99),98.01)
        with self.assertRaises(ValueError): calibrate([1,2],0.99)
        d=data()[['timestamp','segment_id','x']]; d['x']=2
        with self.assertRaises(ValueError): ZScore().fit(d)


if __name__=='__main__': unittest.main(verbosity=2)
