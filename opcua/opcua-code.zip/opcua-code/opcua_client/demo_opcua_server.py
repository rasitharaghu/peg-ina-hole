"""Lightweight demo OPC UA server for testing the Django OPC UA client.

Usage:
  py -3 demo_opcua_server.py

This starts a local OPC UA server at opc.tcp://0.0.0.0:4840 and exposes a few
objects/variables that change over time so you can test discovery, browsing,
and value reads/streams from the client.

Requires: python-opcua (package name: opcua)
Install in your venv: pip install opcua
"""
import random
import time
import logging
from datetime import datetime

try:
    from opcua import ua, Server
except Exception:
    raise RuntimeError("python-opcua is required. Install with: pip install opcua")


def create_demo_server(endpoint="opc.tcp://0.0.0.0:4840"):
    server = Server()
    server.set_endpoint(endpoint)
    uri = "http://examples.freeopcua.github.io"
    idx = server.register_namespace(uri)

    objects = server.get_objects_node()

    demo_obj = objects.add_object(idx, "DemoDevice")

    # Add some variable nodes with different types
    int_var = demo_obj.add_variable(idx, "Int32", 42)
    int_var.set_writable()

    float_var = demo_obj.add_variable(idx, "Float", 3.14)
    float_var.set_writable()

    str_var = demo_obj.add_variable(idx, "String", "hello")
    str_var.set_writable()

    bool_var = demo_obj.add_variable(idx, "Boolean", True)
    bool_var.set_writable()

    # A structured variable (Variant) - store timestamp
    time_var = demo_obj.add_variable(idx, "Timestamp", datetime.utcnow().isoformat())
    time_var.set_writable()

    # Add an array variable
    array_var = demo_obj.add_variable(idx, "Array", [1, 2, 3, 4])
    array_var.set_writable()

    return server, dict(int=int_var, float=float_var, str=str_var, bool=bool_var, time=time_var, array=array_var)


def run_demo_loop(server, nodes, update_interval=1.0):
    logging.info("Starting demo update loop (ctrl-c to stop)")
    try:
        while True:
            # mutate values
            new_int = random.randint(0, 1000)
            new_float = round(random.random() * 100.0, 3)
            new_str = f"msg-{random.randint(1,9999)}"
            new_bool = random.choice([True, False])
            new_time = datetime.utcnow().isoformat()
            new_array = [random.randint(0, 9) for _ in range(6)]

            try:
                nodes["int"].set_value(new_int)
                nodes["float"].set_value(new_float)
                nodes["str"].set_value(new_str)
                nodes["bool"].set_value(new_bool)
                nodes["time"].set_value(new_time)
                nodes["array"].set_value(new_array)
            except Exception as exc:
                logging.exception("Failed writing node values: %s", exc)

            logging.info("Updated values: int=%s float=%s str=%s bool=%s time=%s array=%s", new_int, new_float, new_str, new_bool, new_time, new_array)

            time.sleep(update_interval)
    except KeyboardInterrupt:
        logging.info("Demo loop interrupted by user")


def main():
    logging.basicConfig(level=logging.INFO, format="[%(asctime)s] %(levelname)s: %(message)s")

    endpoint = "opc.tcp://0.0.0.0:4840"
    server, nodes = create_demo_server(endpoint=endpoint)

    try:
        server.start()
    except Exception as exc:
        logging.exception("Failed to start OPC UA server: %s", exc)
        raise

    logging.info("OPC UA demo server started at %s", endpoint)
    logging.info("Available nodes: %s", ", ".join(nodes.keys()))

    try:
        run_demo_loop(server, nodes, update_interval=1.0)
    finally:
        logging.info("Stopping OPC UA server...")
        try:
            server.stop()
        except Exception:
            pass


if __name__ == "__main__":
    main()
