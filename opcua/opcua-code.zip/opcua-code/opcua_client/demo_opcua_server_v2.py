import random
import time
import logging
from datetime import datetime

try:
    from opcua import ua, Server
except Exception:
    raise RuntimeError("python-opcua is required. Install with: pip install opcua")


def create_demo_server(endpoint="opc.tcp://0.0.0.0:4840"):
    server = Server()
    server.set_endpoint(endpoint)
    uri = "http://examples.freeopcua.github.io"
    idx = server.register_namespace(uri)

    objects = server.get_objects_node()

    # Rename the object to something more industrial
    factory_obj = objects.add_object(idx, "ProductionLine_01")

    # Define industrial tags
    # .add_variable(namespace_index, name, default_value)
    temp_var = factory_obj.add_variable(idx, "Temperature", 25.0)
    press_var = factory_obj.add_variable(idx, "Pressure", 1.0)
    torque_var = factory_obj.add_variable(idx, "Torque", 0.0)
    rpm_var = factory_obj.add_variable(idx, "MotorRotation", 0)
    status_var = factory_obj.add_variable(idx, "Status", "Idle")
    fault_var = factory_obj.add_variable(idx, "FaultCode", 0)

    # Make them all writable so the client can potentially change them
    nodes = [temp_var, press_var, torque_var, rpm_var, status_var, fault_var]
    for node in nodes:
        node.set_writable()

    return server, {
        "temperature": temp_var,
        "pressure": press_var,
        "torque": torque_var,
        "rpm": rpm_var,
        "status": status_var,
        "fault": fault_var
    }


def run_demo_loop(server, nodes, update_interval=1.0):
    logging.info("Starting Industrial Simulation loop (ctrl-c to stop)")
    
    # State variables for "smooth" simulation
    current_temp = 70.0
    
    try:
        while True:
            # Simulate realistic behavior
            # 1. Temperature: Drift around 70-75 degrees
            current_temp += random.uniform(-0.5, 0.5)
            
            # 2. RPM & Torque: Linked together
            current_rpm = random.randint(1450, 1550)
            current_torque = round(random.uniform(10.5, 12.0), 2)
            
            # 3. Pressure: Small fluctuations
            current_pressure = round(random.uniform(5.8, 6.2), 2)
            
            # 4. Status Logic
            current_status = "Running" if current_rpm > 0 else "Stopped"
            
            try:
                nodes["temperature"].set_value(round(current_temp, 2))
                nodes["pressure"].set_value(current_pressure)
                nodes["torque"].set_value(current_torque)
                nodes["rpm"].set_value(current_rpm)
                nodes["status"].set_value(current_status)
                # Randomly throw a fault code 1% of the time
                nodes["fault"].set_value(0 if random.random() > 0.01 else 404)
                
            except Exception as exc:
                logging.exception("Failed writing node values: %s", exc)

            logging.info(f"Update -> Temp: {current_temp:.2f}C | RPM: {current_rpm} | Status: {current_status}")

            time.sleep(update_interval)
    except KeyboardInterrupt:
        logging.info("Demo loop interrupted by user")


def main():
    logging.basicConfig(level=logging.INFO, format="[%(asctime)s] %(levelname)s: %(message)s")

    endpoint = "opc.tcp://0.0.0.0:4840"
    server, nodes = create_demo_server(endpoint=endpoint)

    try:
        server.start()
    except Exception as exc:
        logging.exception("Failed to start OPC UA server: %s", exc)
        raise

    logging.info(f"Industrial OPC UA server started at {endpoint}")
    logging.info(f"Nodes created: {list(nodes.keys())}")

    try:
        run_demo_loop(server, nodes, update_interval=1.0)
    finally:
        logging.info("Stopping OPC UA server...")
        server.stop()


if __name__ == "__main__":
    main()