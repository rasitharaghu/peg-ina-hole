from django.contrib import admin
from . import models


@admin.register(models.OPCUANetwork)
class OPCUANetworkAdmin(admin.ModelAdmin):
	list_display = ("name", "created_at")
	search_fields = ("name",)


@admin.register(models.OPCUAServer)
class OPCUAServerAdmin(admin.ModelAdmin):
	list_display = ("name", "endpoint", "created_at")
	search_fields = ("name", "endpoint")


@admin.register(models.OPCUANode)
class OPCUANodeAdmin(admin.ModelAdmin):
	list_display = ("label", "node_id", "server")
	search_fields = ("label", "node_id")
	list_filter = ("server",)


@admin.register(models.OPCUAReading)
class OPCUAReadingAdmin(admin.ModelAdmin):
	list_display = ("node", "value", "timestamp")
	search_fields = ("value",)
	list_filter = ("node",)
