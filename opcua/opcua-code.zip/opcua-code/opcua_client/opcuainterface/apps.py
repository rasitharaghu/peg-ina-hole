from django.apps import AppConfig


class OpcuainterfaceConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'opcuainterface'
