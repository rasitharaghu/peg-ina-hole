from django.core.management.base import BaseCommand, CommandError
from typing import Optional
import time

from opcuainterface.models import OPCUAServer, OPCUAReading
from opcuainterface.opcua_client import SimpleOPCUAClient


class Command(BaseCommand):
    help = "Run a simple OPC UA poller that reads nodes configured on a server and stores readings in the DB."

    def add_arguments(self, parser):
        parser.add_argument("--server-id", type=int, help="ID of OPCUAServer to poll (required)")
        parser.add_argument("--interval", type=float, default=5.0, help="Seconds between polls")
        parser.add_argument("--once", action="store_true", help="Poll once and exit")

    def handle(self, *args, **options):
        server_id: Optional[int] = options.get("server_id")
        interval: float = options.get("interval")
        once: bool = options.get("once")

        if not server_id:
            raise CommandError("--server-id is required. Create an OPCUAServer in admin or fixtures first.")

        try:
            server = OPCUAServer.objects.get(pk=server_id)
        except OPCUAServer.DoesNotExist:
            raise CommandError(f"OPCUAServer id={server_id} not found")

        nodes = list(server.nodes.all())
        if not nodes:
            self.stdout.write(self.style.WARNING("Server has no nodes configured; nothing to poll."))
            return

        self.stdout.write(self.style.SUCCESS(f"Connecting to {server} and polling {len(nodes)} nodes every {interval}s"))

        try:
            with SimpleOPCUAClient(server.endpoint) as client:
                while True:
                    for node in nodes:
                        try:
                            result = client.read_node_value(node.node_id)
                        except Exception as exc:  # pragma: no cover - network/IO
                            self.stderr.write(f"Failed to read {node.node_id}: {exc}")
                            continue

                        OPCUAReading.objects.create(
                            node=node,
                            value=str(result.get("value")),
                            variant_type=result.get("variant_type", ""),
                        )
                        self.stdout.write(f"{node}: {result.get('value')} ({result.get('variant_type')})")

                    if once:
                        self.stdout.write(self.style.SUCCESS("Polled once and exiting (--once)."))
                        return

                    time.sleep(interval)
        except KeyboardInterrupt:
            self.stdout.write(self.style.WARNING("Interrupted by user - exiting."))
