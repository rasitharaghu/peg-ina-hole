from django.db import models
from django.utils import timezone


class OPCUAServer(models.Model):
	"""Represents an OPC UA server endpoint to connect to."""
	name = models.CharField(max_length=200)
	endpoint = models.CharField(max_length=512, help_text="OPC UA endpoint URL, e.g. opc.tcp://localhost:4840")
	# optional grouping/network name
	network = models.ForeignKey(
		"OPCUANetwork",
		on_delete=models.SET_NULL,
		related_name="servers",
		null=True,
		blank=True,
	)
	created_at = models.DateTimeField(default=timezone.now)

	def __str__(self) -> str:  # pragma: no cover - trivial
		return f"{self.name} ({self.endpoint})"


class OPCUANode(models.Model):
	"""A node on a specific OPC UA server to poll."""
	server = models.ForeignKey(OPCUAServer, on_delete=models.CASCADE, related_name="nodes")
	node_id = models.CharField(max_length=256, help_text="NodeId as string, e.g. ns=2;s=Demo.Static.Scalar.Int32")
	label = models.CharField(max_length=200, blank=True)
	node_type = models.CharField(max_length=20, choices=[('Object', 'Object'), ('Variable', 'Variable')], default='Variable')
	data_type = models.CharField(max_length=50, default='Double')
	parent_node_id = models.CharField(max_length=255, default='i=85')

	def __str__(self) -> str:  # pragma: no cover - trivial
		return f"{self.label or self.node_id} @ {self.server.name}"


class OPCUAReading(models.Model):
	"""A single polled value for an OPC UA node."""
	node = models.ForeignKey(OPCUANode, on_delete=models.CASCADE, related_name="readings")
	timestamp = models.DateTimeField(default=timezone.now, db_index=True)
	value = models.TextField()
	variant_type = models.CharField(max_length=100, blank=True)
	value_int = models.BigIntegerField(null=True, blank=True, db_index=True)
	value_float = models.FloatField(null=True, blank=True, db_index=True)
	value_bool = models.BooleanField(null=True, blank=True, db_index=True)
	value_string = models.CharField(max_length=512, null=True, blank=True)
	status_code = models.BigIntegerField(default=0, help_text="OPC UA StatusCode")
	value_json = models.JSONField(null=True, blank=True)
	node_id_text = models.CharField(max_length=256, blank=True, db_index=True)
	server_endpoint = models.CharField(max_length=512, blank=True, db_index=True)

	class Meta:
		ordering = ["-timestamp"]
        # Index together for fast time-series lookups per node
		indexes = [
            models.Index(fields=['node', '-timestamp']),
        ]

	def __str__(self) -> str:  # pragma: no cover - trivial
		return f"{self.node.name} ({self.node_id_text}): {self.value} @ {self.timestamp}"
        
	@property
	def typed_value(self):
		"""Returns the value in its correct Python type based on variant_type."""
		if self.value_float is not None: return self.value_float
		if self.value_int is not None: return self.value_int
		if self.value_bool is not None: return self.value_bool
		return self.value_string or self.value



class OPCUANetwork(models.Model):
	"""Optional grouping representing a network or discovery group of OPC UA servers."""
	name = models.CharField(max_length=200)
	description = models.TextField(blank=True)
	created_at = models.DateTimeField(default=timezone.now)

	def __str__(self) -> str:  # pragma: no cover - trivial
		return self.name
