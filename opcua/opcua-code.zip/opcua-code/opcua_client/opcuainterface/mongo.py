"""Simple MongoDB helper for storing OPCUA readings.

This module centralizes connection handling and provides a small API used by
views/streaming code to persist and query readings efficiently.

Configuration: read MONGODB_URI and MONGODB_DB from environment or defaults.
"""
import os
from dotenv import load_dotenv
from pymongo import MongoClient, ASCENDING, DESCENDING
from pymongo.errors import PyMongoError
from datetime import datetime, timezone

# Load .env file into environment (if present). This makes it easy to set
# MONGODB_URI and MONGODB_DB via a project-local .env file during development.
load_dotenv()

MONGO_URI = os.environ.get('MONGODB_URI', 'mongodb://localhost:27017')
MONGO_DB = os.environ.get('MONGODB_DB', 'opcua_client')

_client = None

def get_client():
    global _client
    if _client is None:
        _client = MongoClient(MONGO_URI)
    return _client

def get_db():
    return get_client()[MONGO_DB]

def ensure_indexes():
    db = get_db()
    col = db.readings
    # Compound index for queries by node/server and time
    col.create_index([('node_pk', ASCENDING), ('timestamp', DESCENDING)])
    col.create_index([('server_endpoint', ASCENDING), ('timestamp', DESCENDING)])
    col.create_index([('node_id', ASCENDING)])

def save_reading_doc(doc: dict):
    """Insert a reading document. Adds server-side timestamp if missing.

    Returns the inserted_id or raises PyMongoError.
    """
    db = get_db()
    if 'timestamp' not in doc:
        # store timezone-aware UTC timestamps
        doc['timestamp'] = datetime.now(timezone.utc)
 
    # ensure basic normalized fields
    if 'node_pk' in doc:
        try:
            doc['node_pk'] = int(doc['node_pk'])
        except Exception:
            pass
    if 'value' in doc and not isinstance(doc['value'], (str, int, float, bool, dict, list)):
        # stringify unknown types
        doc['value'] = str(doc['value'])
    res = db.readings.insert_one(doc)
    return res.inserted_id

def query_readings(filter=None, limit=200, sort=[('timestamp', DESCENDING)]):
    db = get_db()
    flt = filter or {}
    cursor = db.readings.find(flt).sort(sort).limit(limit)
    return list(cursor)
