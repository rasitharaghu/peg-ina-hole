"""Simple wrapper around python-opcua Client used by the management command.

This module keeps a thin layer so the rest of the Django code doesn't need
to import the third-party package directly. Install dependency with:

    pip install opcua

"""
from typing import Any

try:
    from opcua import Client
except Exception:  
    Client = None

import socket
from typing import Iterable, List, Dict, Optional


def discover_servers(candidate_hosts: Optional[Iterable[str]] = None, ports: Optional[Iterable[int]] = None, timeout: float = 1.0) -> List[Dict[str, str]]:
    """Best-effort discovery: try to contact candidate hosts on candidate ports and return reachable endpoints.

    This is a pragmatic approach: a full OPC UA Local Discovery scan (LDS) isn't implemented here.
    If you run an LDS or have a known discovery URL, prefer using that. The function returns a list
    of dicts: {'endpoint': 'opc.tcp://host:port', 'name': <host>} for reachable endpoints.
    """
    if Client is None:
        raise RuntimeError("python-opcua package not available. Install with: pip install opcua")

    if candidate_hosts is None:
        candidate_hosts = ["localhost", "127.0.0.1"]
    if ports is None:
        ports = [4840]

    results: List[Dict[str, str]] = []
    for host in candidate_hosts:
        for port in ports:
            endpoint = f"opc.tcp://{host}:{port}"
            try:
                # quick TCP probe first to avoid slow client timeouts
                with socket.create_connection((host, port), timeout=timeout):
                    pass
            except Exception:
                continue

            try:
                c = Client(endpoint)
                c.connect()
                try:
                    # ask server for endpoints as a sanity check
                    eps = c.get_endpoints()
                    if eps:
                        results.append({"endpoint": endpoint, "name": host})
                finally:
                    try:
                        c.disconnect()
                    except Exception:
                        pass
            except Exception:
                # ignore errors for unreachable/handshakes
                continue

    return results


def browse_nodes(endpoint: str, max_nodes: int = 30) -> List[Dict[str, str]]:
    """Connect to endpoint and return a list of variable nodes (nodeid, browse_name, display_name).

    This function will traverse the Objects node breadth-first and collect Variable nodes up to max_nodes.
    """
    if Client is None:
        raise RuntimeError("python-opcua package not available. Install with: pip install opcua")

    found: List[Dict[str, str]] = []
    c = Client(endpoint)
    c.connect()
    try:
        root = c.get_root_node()
        objects = root.get_child(["0:Objects"]) if True else root.get_children()

        # BFS queue: list of node objects
        queue = [objects] if not isinstance(objects, list) else objects
        visited = set()

        while queue and len(found) < max_nodes:
            node = queue.pop(0)
            try:
                node_id = node.nodeid.to_string()
            except Exception:
                node_id = str(node)

            if node_id in visited:
                continue
            visited.add(node_id)

            try:
                # Node class check
                try:
                    nodeclass = node.get_node_class()
                except Exception:
                    nodeclass = None

                if nodeclass is not None:
                    # NodeClass.Variable is typically 2 but we avoid coupling to ua enum
                    # Best-effort: attempt to get value for variables
                    try:
                        val = node.get_value()
                        found.append({"node_id": node_id, "display_name": str(node.get_display_name().Text), "value_preview": str(val)})
                    except Exception:
                        # not a variable or cannot read; continue traversal
                        pass

                # Enqueue children
                try:
                    children = node.get_children()
                    for cnode in children:
                        if len(found) >= max_nodes:
                            break
                        queue.append(cnode)
                except Exception:
                    pass
            except Exception:
                # defensive: keep going
                continue

    finally:
        try:
            c.disconnect()
        except Exception:
            pass

    return found


class SimpleOPCUAClient:
    def __init__(self, endpoint: str):
        if Client is None:
            raise RuntimeError(
                "python-opcua package not available. Install with: pip install opcua"
            )
        self._endpoint = endpoint
        self._client = Client(self._endpoint)

    def __enter__(self):
        self._client.connect()
        return self

    def __exit__(self, exc_type, exc, tb):
        try:
            self._client.disconnect()
        except Exception:
            pass

    def read_node_value(self, node_id: str) -> dict[str, Any]:
        """Read a node value and return a dict with value and variant type."""
        node = self._client.get_node(node_id)
        val = node.get_value()
        # variant type is best-effort: use python type name
        return {"value": val, "variant_type": type(val).__name__}
