(function(){
  // Simple frontend to call the API endpoints and render nicer UI
  const auth = '';

  function qs(selector){ return document.querySelector(selector); }

  function qsa(selector){ return Array.from(document.querySelectorAll(selector)); }

  async function refreshServers(){
    const res = await fetch('/opcuainterface/servers/');
    const data = await res.json();
    const ul = qs('#serversList'); ul.innerHTML='';
    data.forEach(s => {
      const li = document.createElement('li');
      li.className = 'server-item';
      li.innerHTML = `<a class="server-link" href='/opcuainterface/servers/${s.id}/'>${s.name}</a> <div class="muted">${s.endpoint}</div>`;
      ul.appendChild(li);
    });
  }

  async function discover(){
    const hosts = qs('#hosts').value;
    const ports = qs('#ports').value;
    const res = await fetch(`/opcuainterface/discover?hosts=${encodeURIComponent(hosts)}&ports=${encodeURIComponent(ports)}`);
    const data = await res.json();
    qs('#discoverResults').textContent = JSON.stringify(data, null, 2);
    const btn = qs('#discoverBtn'); if(btn) showTooltip(btn, 'Discovery complete', 1800);
  }

  async function addServer(){
    const name = qs('#add_name').value.trim();
    const endpoint = qs('#add_endpoint').value.trim();
    if(!name || !endpoint){ qs('#addResult').textContent = 'Name and endpoint are required'; showTooltip(qs('#addServerBtn'),'Name & endpoint required',1800); return; }
    const body = { name, endpoint };
    const res = await fetch('/opcuainterface/servers/add/', { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify(body) });
    const data = await res.json();
    qs('#addResult').textContent = JSON.stringify(data, null, 2);
    const btn = qs('#addServerBtn');
    if(res.ok){ showTooltip(btn, 'Server added', 2200); } else { showTooltip(btn, 'Add failed', 2200); }
    await refreshServers();
  }

  function getServerId(){
    // read server id from body data attribute if present
    const el = document.body.getAttribute('data-server-id');
    return el ? Number(el) : null;
  }
  
  async function refreshNodes(){
    const serverId = getServerId();
    if(!serverId){ return; }
    const res = await fetch(`/opcuainterface/servers/${serverId}/nodes/`);
    const data = await res.json();
    const tbody = qs('#nodesList tbody'); tbody.innerHTML='';
    data.forEach(n => {
      const tr = document.createElement('tr');
      tr.innerHTML = `<td><input type="checkbox" class="nodeCheckbox" data-pk="${n.id}" /></td><td>${n.id}</td><td>${(n.label||'')}</td><td><code>${n.node_id}</code></td>`;
      tbody.appendChild(tr);
    });
    // re-init select-all wiring after DOM updated
    initSelectAll();
  }

  // select all nodes checkbox handling
  function initSelectAll(){
    const sel = qs('#selectAllNodes');
    if(!sel) return;
    sel.addEventListener('change', ()=>{
      const checked = sel.checked;
      qsa('.nodeCheckbox').forEach(cb => { cb.checked = checked; });
    });
  }

  function getSelectedNodePks(){
    return qsa('.nodeCheckbox').filter(cb => cb.checked).map(cb => cb.dataset.pk);
  }

  async function importTags(){
    const serverId = getServerId();
    if(!serverId){ showTooltip(qs('#importTagsBtn'), 'No server id', 1600); return; }
    const btn = qs('#importTagsBtn');
    btn.disabled = true; btn.textContent = 'Importing...';
    try{
      const res = await fetch(`/opcuainterface/servers/${serverId}/import_tags/`, { method: 'POST' });
      const data = await res.json();
      qs('#streamOutput') && (qs('#streamOutput').textContent = '');
      showTooltip(btn, res.ok ? `Imported ${data.created} nodes` : 'Import failed', 2200);
      await refreshNodes();
    }catch(err){
      showTooltip(btn, 'Import failed', 2200);
    }finally{
      btn.disabled = false; btn.textContent = 'Import Tags';
    }
  }

  function startStream(){
    const nodePk = qs('#stream_node_pk').value.trim();
    if(!nodePk){ qs('#streamOutput').textContent = 'Enter node PK to stream'; showTooltip(qs('#startStream'),'Enter node PK',1600); return; }
    const interval = qs('#stream_interval').value || '1';
    const out = qs('#streamOutput'); out.textContent='';
  // close any existing stream first
    if(window._opcua_es){ try{ window._opcua_es.close(); }catch(e){} }
    const es = new EventSource(`/opcuainterface/stream/node/${nodePk}/?interval=${interval}`);
    window._opcua_es = es;
    es.onmessage = e => {
      try{
        const parsed = JSON.parse(e.data);
        out.textContent += JSON.stringify(parsed, null, 2) + '\n';
        // optionally save incoming reading to DB
        if(qs('#saveReadings') && qs('#saveReadings').checked){
          // send a POST to save the value
          try{
            fetch('/opcuainterface/readings/save/', {
              method: 'POST', headers: {'Content-Type':'application/json'},
              body: JSON.stringify({ node_pk: Number(nodePk), value: parsed.value, variant_type: parsed.variant_type || '', timestamp: parsed.timestamp })
            });
            // increment saved count
            const sc = qs('#savedCount'); if(sc){ const cur = Number(sc.dataset.count || 0) + 1; sc.dataset.count = cur; sc.textContent = `${cur} saved`; }
          }catch(err){ /* ignore save errors for now */ }
        }
      }catch(err){ out.textContent += e.data + '\n'; }
    };
    es.addEventListener('error', e => { out.textContent += '[SSE error]\n'; es.close(); });
    const btn = qs('#startStream'); if(btn) showTooltip(btn, 'Streaming started', 1500);
    setStreamState(true);
  }

  function stopStream(){
    if(window._opcua_es){ try{ window._opcua_es.close(); }catch(e){} window._opcua_es = null; showTooltip(qs('#stopStream'),'Stream stopped',1200); }
    setStreamState(false);
  }

  // Multi-stream: start streaming multiple nodes via server-side grouped stream
  function startMultiStream(){
    const pks = getSelectedNodePks();
    if(!pks || pks.length===0){ showTooltip(qs('#startMultiStream'), 'Select one or more nodes', 1600); return; }
    const interval = qs('#stream_interval').value || '1';
    // close any existing multi stream
    if(window._opcua_multi_es){ try{ window._opcua_multi_es.close(); }catch(e){} }
    const url = `/opcuainterface/stream/multi/?node_pks=${encodeURIComponent(pks.join(','))}&interval=${encodeURIComponent(interval)}`;
    const es = new EventSource(url);
    window._opcua_multi_es = es;
    const out = qs('#streamOutput'); out.textContent = '';
    es.onmessage = e => {
      try{
        const parsed = JSON.parse(e.data);
        out.textContent += JSON.stringify(parsed, null, 2) + '\n';
        if(qs('#saveReadings') && qs('#saveReadings').checked){
          try{
            fetch('/opcuainterface/readings/save/', { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify({ node_pk: parsed.node_pk, value: parsed.value, variant_type: parsed.variant_type || '', timestamp: parsed.timestamp, endpoint: parsed.server_endpoint }) });
            const sc = qs('#savedCount'); if(sc){ const cur = Number(sc.dataset.count || 0) + 1; sc.dataset.count = cur; sc.textContent = `${cur} saved`; }
          }catch(err){}
        }
      }catch(err){ out.textContent += e.data + '\n'; }
    };
    es.addEventListener('error', e => { out.textContent += '[SSE error]\n'; es.close(); });
    setMultiStreamState(true);
    showTooltip(qs('#startMultiStream'), 'Multi streaming started', 1400);
  }

  function stopMultiStream(){
    if(window._opcua_multi_es){ try{ window._opcua_multi_es.close(); }catch(e){} window._opcua_multi_es = null; showTooltip(qs('#stopMultiStream'),'Multi stream stopped',1200); }
    setMultiStreamState(false);
  }

  function setMultiStreamState(isStreaming){
    const start = qs('#startMultiStream');
    const stop = qs('#stopMultiStream');
    if(isStreaming){ if(start){ start.disabled = true; start.classList.remove('active'); } if(stop){ stop.disabled = false; stop.classList.add('active'); } } else { if(start){ start.disabled = false; start.classList.add('active'); } if(stop){ stop.disabled = true; stop.classList.remove('active'); } }
  }

  function setStreamState(isStreaming){
    const start = qs('#startStream');
    const stop = qs('#stopStream');
    if(isStreaming){
      if(start){ start.disabled = true; start.classList.remove('active'); }
      if(stop){ stop.disabled = false; stop.classList.add('active'); }
    } else {
      if(start){ start.disabled = false; start.classList.add('active'); }
      if(stop){ stop.disabled = true; stop.classList.remove('active'); }
    }
  }

  // Tooltip helper: creates a temporary tooltip near element
  function showTooltip(el, message, duration=1800){
    if(!el) return;
    const tip = document.createElement('div'); tip.className='tooltip'; tip.textContent = message; document.body.appendChild(tip);
    // position after inserted so width/height are available
    requestAnimationFrame(()=>{
      const rect = el.getBoundingClientRect();
      const tipRect = tip.getBoundingClientRect();
      const left = rect.left + (rect.width/2) - (tipRect.width/2);
      const top = rect.top - tipRect.height - 8 + window.scrollY;
      tip.style.left = Math.max(8, left) + 'px';
      tip.style.top = (top) + 'px';
      tip.classList.add('show');
    });
    setTimeout(()=>{ tip.classList.remove('show'); setTimeout(()=>tip.remove(),200); }, duration);
  }

  // bind on index if elements exist
  if(qs('#discoverBtn')){
    qs('#discoverBtn').addEventListener('click', discover);
    qs('#refreshServers').addEventListener('click', refreshServers);
    qs('#addServerBtn').addEventListener('click', addServer);
    refreshServers();
  }

  if(qs('#refreshNodes')){
    qs('#refreshNodes').addEventListener('click', refreshNodes);
    qs('#startStream').addEventListener('click', startStream);
    if(qs('#startMultiStream')) qs('#startMultiStream').addEventListener('click', startMultiStream);
    if(qs('#stopMultiStream')) qs('#stopMultiStream').addEventListener('click', stopMultiStream);
    if(qs('#importTagsBtn')) qs('#importTagsBtn').addEventListener('click', importTags);
    if(qs('#stopStream')) qs('#stopStream').addEventListener('click', stopStream);
    refreshNodes();
    // initialize stream buttons state
    setStreamState(false);
  }

  // Readings viewer: client-side filter + pagination (works on rendered table rows)
  if(qs('#readingsTable')){
    const pageSize = 25;
    let pageIndex = 0;
    const rows = Array.from(qs('#readingsTable tbody').querySelectorAll('tr'));
    function updateCount(){ qs('#showCount').textContent = rows.length; }

    function renderPage(){
      const start = pageIndex * pageSize; const end = start + pageSize;
      rows.forEach((r, i)=>{ r.style.display = (i>=start && i<end) ? '' : 'none'; });
      qs('#pageInfo').textContent = `Page ${pageIndex+1} (${Math.min(start+1, rows.length)}-${Math.min(end, rows.length)} of ${rows.length})`;
    }

    function applyFilters(){
      const fServer = qs('#filter_server').value.trim().toLowerCase();
      const fNode = qs('#filter_nodeid').value.trim().toLowerCase();
      const fVal = qs('#filter_value').value.trim().toLowerCase();
      rows.forEach(r => {
        const server = r.querySelector('.r-server')?.textContent.toLowerCase() || '';
        const nodeid = r.querySelector('.r-nodeid')?.textContent.toLowerCase() || '';
        const nodepk = r.querySelector('.r-nodepk')?.textContent.toLowerCase() || '';
        const val = r.querySelector('.r-value')?.textContent.toLowerCase() || '';
        let visible = true;
        if(fServer && !server.includes(fServer)) visible = false;
        if(fNode && !(nodeid.includes(fNode) || nodepk.includes(fNode))) visible = false;
        if(fVal && !val.includes(fVal)) visible = false;
        r.style.display = visible ? '' : 'none';
      });
      // rebuild visible rows array for pagination
      const visibleRows = rows.filter(r => r.style.display !== 'none');
      // temporarily mark others hidden; then show page 1 of visible
      rows.forEach(r => r.style.display = 'none');
      visibleRows.forEach((r,i)=>{ r.style.display = (i<pageSize) ? '' : 'none'; });
      pageIndex = 0;
      qs('#pageInfo').textContent = `Page 1 (${Math.min(1, visibleRows.length)}-${Math.min(pageSize, visibleRows.length)} of ${visibleRows.length})`;
      qs('#showCount').textContent = visibleRows.length;
      // store visible set on the container for prev/next navigation
      qs('#readingsTable').dataset.visible = visibleRows.map(r => Array.from(r.parentNode.children).indexOf(r)).join(',');
    }

    function clearFilters(){ qs('#filter_server').value=''; qs('#filter_nodeid').value=''; qs('#filter_value').value=''; rows.forEach(r=>r.style.display=''); updateCount(); renderPage(); }

    qs('#applyFilters').addEventListener('click', applyFilters);
    qs('#clearFilters').addEventListener('click', clearFilters);
    qs('#prevPage').addEventListener('click', ()=>{
      if(pageIndex<=0) return; pageIndex--; renderPage();
    });
    qs('#nextPage').addEventListener('click', ()=>{
      const maxPage = Math.ceil(rows.length / pageSize) - 1; if(pageIndex>=maxPage) return; pageIndex++; renderPage();
    });

    // initial render
    updateCount(); renderPage();
  }
})();