from django.conf import settings
from .models import OPCUAReading
from . import mongo  # Your existing mongo module
 # Essential import
from django.utils import timezone

def save_opcua_reading(doc, django_node_obj=None):
    """
    Dispatches the saving logic based on the configured backend.
    'doc' is the dictionary of data.
    'django_node_obj' is the actual OPCUANode instance (needed for SQLite).
    """
    backend = getattr(settings, 'INGESTION_STORAGE_BACKEND', 'sqlite')

    if backend == 'mongodb':
        # Save to Mongo using your existing logic
        return mongo.save_reading_doc(doc)
    
    else:
        # Save to SQLite (Django ORM) using models.py
        reading = OPCUAReading.objects.create(
            node=django_node_obj,
            timestamp=doc.get('timestamp') or timezone.now(),
            value=str(doc.get('value')),
            variant_type=doc.get('variant_type', ''),
            value_int=doc.get('value_int'),
            value_float=doc.get('value_float'),
            value_bool=doc.get('value_bool'),
            value_json=doc.get('value_json'),
            node_id_text=doc.get('node_id', ''),
            server_endpoint=doc.get('server_endpoint', '')
        )
        return str(reading.id)