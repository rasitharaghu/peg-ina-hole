from django.urls import path
from . import views

app_name = "opcuainterface"

urlpatterns = [
    path("", views.ui_index, name="ui_index"),
    path("servers/", views.servers_list, name="servers_list"),
    path("discover/", views.discover, name="discover"),
    path("servers/<int:server_id>/", views.ui_server_detail, name="ui_server_detail"),
    path("servers/<int:server_id>/nodes/", views.server_nodes, name="server_nodes"),
    path("servers/<int:server_id>/import_tags/", views.import_tags, name="import_tags"),
    path("nodes/<int:node_id>/readings/", views.node_readings, name="node_readings"),
    path("readings/", views.readings_list, name="readings_list"),
    path("servers/add/", views.add_server, name="add_server"),
    path("tags/fetch/", views.fetch_tags, name="fetch_tags"),
    path("stream/node/<int:node_pk>/", views.stream_tag, name="stream_tag"),
    path("stream/direct/", views.stream_node_direct, name="stream_node_direct"),
    path("readings/save/", views.save_reading, name="save_reading"),
    path("stream/multi/", views.stream_multi_nodes, name="stream_multi_nodes"),
    path("servers/<int:server_id>/export_xml/", views.export_nodes_xml, name="export_nodes_xml"),
]
