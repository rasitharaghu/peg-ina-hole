from django.http import JsonResponse, Http404, StreamingHttpResponse
from django.shortcuts import get_object_or_404, render
from django.views.decorators.http import require_http_methods
from django.views.decorators.csrf import csrf_exempt

from opcuainterface.storage import save_opcua_reading
from django.conf import settings 

from .models import OPCUAServer, OPCUANode, OPCUAReading
from . import mongo
from .opcua_client import discover_servers, browse_nodes, SimpleOPCUAClient

import json
import time
from django.views.decorators.csrf import csrf_exempt
from django.db import transaction
from django.views.decorators.http import require_POST
from django.utils import timezone
import logging
import xml.etree.ElementTree as ET
from django.http import HttpResponse
import xml.etree.ElementTree as ET
from django.http import HttpResponse
from django.shortcuts import get_object_or_404


# SSE content type constant
EVENT_STREAM_CT = "text/event-stream"

if getattr(settings, 'INGESTION_STORAGE_BACKEND', 'sqlite') == 'mongodb':
    try:
        mongo.ensure_indexes()
    except Exception:
        pass


def _error(code: int, message: str, http_status: int = 400):
	return JsonResponse({"error": {"code": code, "message": message}}, status=http_status)


@require_http_methods(["GET"])
def servers_list(request):
	servers = OPCUAServer.objects.all().values("id", "name", "endpoint", "network_id")
	return JsonResponse(list(servers), safe=False)


@require_http_methods(["GET"])
def discover(request):
	"""Discover reachable OPC UA endpoints.

	Query params (optional): hosts (comma-separated), ports (comma-separated), timeout (float seconds)
	"""
	hosts = request.GET.get("hosts")
	ports = request.GET.get("ports")
	timeout = float(request.GET.get("timeout", "1.0"))

	host_list = [h.strip() for h in hosts.split(",")] if hosts else None
	port_list = [int(p.strip()) for p in ports.split(",")] if ports else None

	try:
		results = discover_servers(candidate_hosts=host_list, ports=port_list, timeout=timeout)
	except RuntimeError as exc:
		return _error(1000, str(exc), http_status=500)
	except Exception as exc:
		return _error(1001, f"Discovery failed: {exc}", http_status=500)

	return JsonResponse({"results": results})


@require_http_methods(["GET"])
def server_nodes(request, server_id: int):
	server = get_object_or_404(OPCUAServer, pk=server_id)
	nodes = server.nodes.all().values("id", "node_id", "label")
	return JsonResponse(list(nodes), safe=False)


@require_http_methods(["GET"])
def node_readings(request, node_id: int):
    node = get_object_or_404(OPCUANode, pk=node_id)
    backend = getattr(settings, 'INGESTION_STORAGE_BACKEND', 'sqlite')
    data = []

    try:
        if backend == 'mongodb':
            docs = mongo.query_readings(filter={'node_pk': node.id}, limit=50)
            for d in docs:
                data.append({
                    "timestamp": d.get('timestamp').isoformat() if d.get('timestamp') else None,
                    "value": d.get('value'),
                    "variant_type": d.get('variant_type', ''),
                })
        else:
            # Query the SQLite relationship defined in models.py
            readings = node.readings.all()[:50] 
            for r in readings:
                data.append({
                    "timestamp": r.timestamp.isoformat() if r.timestamp else None,
                    "value": r.value,
                    "variant_type": r.variant_type,
                })
    except Exception as exc:
        return _error(1200, f"Failed to query readings: {exc}", http_status=500)

    return JsonResponse({"node": node.node_id, "label": node.label, "readings": data})


@csrf_exempt
@require_http_methods(["POST"])
def add_server(request):
	"""Add an OPC UA server record.

	Accepts JSON: {"name": "..., "endpoint": "opc.tcp://...", "network_id": optional}
	"""
	try:
		payload = json.loads(request.body.decode("utf-8"))
	except Exception:
		return _error(1002, "Invalid JSON body", http_status=400)

	name = payload.get("name")
	endpoint = payload.get("endpoint")
	network_id = payload.get("network_id")

	if not name or not endpoint:
		return _error(1003, "Both 'name' and 'endpoint' are required", http_status=400)

	# basic validation for endpoint shape
	if not endpoint.startswith("opc.tcp://"):
		return _error(1004, "Endpoint must start with 'opc.tcp://'", http_status=400)

	try:
		server = OPCUAServer.objects.create(name=name, endpoint=endpoint, network_id=network_id)
	except Exception as exc:
		return _error(1005, f"Failed to create server record: {exc}", http_status=500)

	return JsonResponse({"id": server.id, "name": server.name, "endpoint": server.endpoint}, status=201)


@require_http_methods(["GET"])
def fetch_tags(request):
	"""Fetch tags (variable nodes) from an OPC UA server.

	Query params: server_id OR endpoint ; optional max_nodes
	"""
	server_id = request.GET.get("server_id")
	endpoint = request.GET.get("endpoint")
	max_nodes = int(request.GET.get("max_nodes", "30"))

	if server_id:
		try:
			server = OPCUAServer.objects.get(pk=int(server_id))
			endpoint = server.endpoint
		except OPCUAServer.DoesNotExist:
			return _error(1006, "Server not found", http_status=404)

	if not endpoint:
		return _error(1007, "Either server_id or endpoint query parameter is required", http_status=400)

	try:
		tags = browse_nodes(endpoint, max_nodes=max_nodes)
	except RuntimeError as exc:
		return _error(1000, str(exc), http_status=500)
	except Exception as exc:
		return _error(1008, f"Failed to browse server: {exc}", http_status=500)

	return JsonResponse({"endpoint": endpoint, "tags": tags})


@require_http_methods(["GET"])
def stream_tag(request, node_pk: int):
	"""Stream real-time updates for a configured OPCUANode using Server-Sent Events (SSE).

	Query params: interval (seconds, float)
	NOTE: This is a simple SSE implementation that will block the worker handling the request.
	For production use, consider using Django Channels or a dedicated websocket server.
	"""
	node = get_object_or_404(OPCUANode, pk=node_pk)
	interval = float(request.GET.get("interval", "1.0"))

	def event_stream():
		try:
			with SimpleOPCUAClient(node.server.endpoint) as client:
				# get node proxy
				try:
					ua_node = client._client.get_node(node.node_id)
				except Exception as exc:
					yield f"event: error\ndata: {json.dumps({'code': 1010, 'message': 'Node access failed', 'detail': str(exc)})}\n\n"
					return

				while True:
					try:
						val = ua_node.get_value()
						payload = {"node_id": node.node_id, "value": str(val), "timestamp": time.time()}
						yield f"data: {json.dumps(payload)}\n\n"
					except Exception as exc:
						yield f"event: error\ndata: {json.dumps({'code': 1011, 'message': 'Read failed', 'detail': str(exc)})}\n\n"
						return
					time.sleep(interval)
		except Exception as exc:
			yield f"event: error\ndata: {json.dumps({'code': 1012, 'message': 'Connection failed', 'detail': str(exc)})}\n\n"

	return StreamingHttpResponse(event_stream(), content_type=EVENT_STREAM_CT)


@require_http_methods(["GET"])
def stream_node_direct(request):
	"""Stream by providing endpoint and node_id as query params. Useful for quick testing.

	Query params:
	  - endpoint: opc.tcp://host:port
	  - node_id: the OPC UA NodeId string (e.g. ns=2;s=Demo.Static.Scalar.Int32)
	  - interval: seconds between reads (float)
	"""
	endpoint = request.GET.get("endpoint")
	node_id = request.GET.get("node_id")
	if not endpoint or not node_id:
		return _error(1020, "Both 'endpoint' and 'node_id' query parameters are required", http_status=400)

	try:
		interval = float(request.GET.get("interval", "1.0"))
		if interval <= 0:
			raise ValueError("interval must be positive")
	except Exception as exc:
		return _error(1021, f"Invalid interval: {exc}", http_status=400)

	logger = logging.getLogger(__name__)

	def event_stream_direct():
		try:
			with SimpleOPCUAClient(endpoint) as client:
				try:
					ua_node = client._client.get_node(node_id)
				except Exception as exc:
					logger.exception("Node access failed for %s@%s", node_id, endpoint)
					yield f"event: error\ndata: {json.dumps({'code': 1010, 'message': 'Node access failed', 'detail': str(exc)})}\n\n"
					return

				while True:
					try:
						val = ua_node.get_value()
						payload = {"node_id": node_id, "value": str(val), "timestamp": time.time()}
						yield f"data: {json.dumps(payload)}\n\n"
					except Exception as exc:
						logger.exception("Read failed for %s@%s", node_id, endpoint)
						yield f"event: error\ndata: {json.dumps({'code': 1011, 'message': 'Read failed', 'detail': str(exc)})}\n\n"
						return
					time.sleep(interval)
		except Exception as exc:
			logger.exception("Connection failed to %s", endpoint)
			yield f"event: error\ndata: {json.dumps({'code': 1012, 'message': 'Connection failed', 'detail': str(exc)})}\n\n"

	return StreamingHttpResponse(event_stream_direct(), content_type=EVENT_STREAM_CT)


@require_http_methods(["GET"])
def stream_multi_nodes(request):
	"""Stream multiple nodes provided by DB node PKs (node_pks comma-separated) or by node_ids with endpoints.

	Query params:
	  - node_pks=1,2,3  (preferred; nodes must belong to potentially multiple servers)
	  - interval=1.0
	The endpoint will open one OPC UA client per server and read all nodes for that server each interval.
	"""
	node_pks = request.GET.get("node_pks")
	interval = float(request.GET.get("interval", "1.0"))
	if not node_pks:
		return _error(1030, "node_pks query parameter is required (comma-separated ids)", http_status=400)

	try:
		pks = [int(x) for x in node_pks.split(",") if x.strip()]
	except Exception:
		return _error(1031, "Invalid node_pks format", http_status=400)

	nodes = list(OPCUANode.objects.filter(pk__in=pks).select_related("server"))
	if not nodes:
		return _error(1032, "No nodes found for provided ids", http_status=404)

	# group nodes by server endpoint
	servers_map = {}
	for n in nodes:
		ep = n.server.endpoint
		servers_map.setdefault(ep, []).append(n)

	logger = logging.getLogger(__name__)

	def event_stream_multi():
		clients = {}
		try:
			# Open clients for each server
			for ep in servers_map.keys():
				try:
					clients[ep] = SimpleOPCUAClient(ep)
					clients[ep].__enter__()
				except Exception as exc:
					logger.exception("Failed to connect to server %s: %s", ep, exc)
					yield f"event: error\ndata: {json.dumps({'code': 1012, 'message': f'Connection failed to {ep}', 'detail': str(exc)})}\n\n"

			while True:
				for ep, nodelist in servers_map.items():
					client = clients.get(ep)
					if client is None:
						continue
					for node in nodelist:
						try:
							ua_node = client._client.get_node(node.node_id)
							val = ua_node.get_value()
							payload = {"node_pk": node.id, "node_id": node.node_id, "value": str(val), "variant_type": type(val).__name__, "timestamp": time.time(), "server_endpoint": ep}
							yield f"data: {json.dumps(payload)}\n\n"
						except Exception as exc:
							logger.exception("Read failed for %s@%s", node.node_id, ep)
							yield f"event: error\ndata: {json.dumps({'code': 1011, 'message': f'Read failed for {node.node_id}', 'detail': str(exc)})}\n\n"
				time.sleep(interval)
		finally:
			# disconnect all clients
			for c in clients.values():
				try:
					c.__exit__(None, None, None)
				except Exception:
					pass

	return StreamingHttpResponse(event_stream_multi(), content_type=EVENT_STREAM_CT)


def ui_index(request):
	"""Render a simple GUI page for listing servers and performing discovery."""
	return render(request, "opcuainterface/index.html")


def ui_server_detail(request, server_id: int):
	server = get_object_or_404(OPCUAServer, pk=server_id)
	return render(request, "opcuainterface/server_detail.html", {"server": server})


@require_http_methods(["GET"])
def readings_list(request):
    """Simple viewer for recent saved readings across nodes."""
    backend = getattr(settings, 'INGESTION_STORAGE_BACKEND', 'sqlite')
    data = []

    try:
        if backend == 'mongodb':
            # Original MongoDB logic
            docs = mongo.query_readings(limit=30)
            for d in docs:
                data.append({
                    'id': str(d.get('_id')),
                    'server': d.get('server_endpoint', d.get('server', '')),
                    'node_pk': d.get('node_pk'),
                    'node_id': d.get('node_id', ''),
                    'value': d.get('value'),
                    'variant_type': d.get('variant_type', ''),
                    'timestamp': d.get('timestamp'),
                })
        else:
            # New SQLite logic using the Django ORM
            # We use select_related to avoid N+1 queries for server info
            readings = OPCUAReading.objects.all().select_related('node__server')[:30]
            for r in readings:
                data.append({
                    'id': r.id,
                    'server': r.server_endpoint or (r.node.server.endpoint if r.node else ''),
                    'node_pk': r.node.id if r.node else None,
                    'node_id': r.node_id_text or (r.node.node_id if r.node else ''),
                    'value': r.value,
                    'variant_type': r.variant_type,
                    'timestamp': r.timestamp,
                })

    except Exception as exc:
        return _error(1201, f"Failed to query readings: {exc}", http_status=500)

    return render(request, 'opcuainterface/readings.html', {'readings': data})


@csrf_exempt
@require_http_methods(["POST"])
def import_tags(request, server_id: int):
	"""Fetch tags from the server endpoint and create OPCUANode rows for them.

	This is a convenience endpoint used by the UI to populate the nodes table.
	"""
	try:
		server = OPCUAServer.objects.get(pk=server_id)
	except OPCUAServer.DoesNotExist:
		return _error(1006, "Server not found", http_status=404)

	try:
		tags = browse_nodes(server.endpoint, max_nodes=30)
	except Exception as exc:
		return _error(1008, f"Failed to browse server: {exc}", http_status=500)

	created = 0
	updated = 0
	details = []
	with transaction.atomic():
		for t in tags:
			node_id = t.get("node_id")
			label = t.get("display_name") or t.get("node_id")
			if not node_id:
				continue
			obj, was_created = OPCUANode.objects.get_or_create(server=server, node_id=node_id, defaults={"label": label})
			if was_created:
				created += 1
			else:
				# update label if blank
				if not obj.label and label:
					obj.label = label
					obj.save()
					updated += 1
			details.append({"id": obj.id, "node_id": obj.node_id, "label": obj.label, "created": was_created})

	return JsonResponse({"created": created, "updated": updated, "total": len(details), "details": details})


@csrf_exempt
@require_POST
def save_reading(request):
	"""Accept a POSTed reading and save to OPCUAReading.

	JSON body: { "node_pk": <int> } OR { "node_id": "...", "endpoint": "opc.tcp://..." },
			   "value": "...", "variant_type": "...", "timestamp": optional float epoch
	"""
	try:
		payload = json.loads(request.body.decode("utf-8"))
	except Exception:
		return _error(1100, "Invalid JSON body", http_status=400)

	node = None
	node_pk = payload.get("node_pk")
	if node_pk:
		try:
			node = OPCUANode.objects.get(pk=int(node_pk))
		except OPCUANode.DoesNotExist:
			return _error(1101, "Node (pk) not found", http_status=404)
	else:
		node_id = payload.get("node_id")
		endpoint = payload.get("endpoint")
		if not node_id or not endpoint:
			return _error(1102, "Either node_pk or (node_id and endpoint) must be provided", http_status=400)
		# try to find server by endpoint
		try:
			server = OPCUAServer.objects.get(endpoint=endpoint)
			node, _ = OPCUANode.objects.get_or_create(server=server, node_id=node_id, defaults={"label": node_id})
		except OPCUAServer.DoesNotExist:
			return _error(1103, "Server with given endpoint not found", http_status=404)

	value = payload.get("value")
	variant_type = payload.get("variant_type", "")
	ts = payload.get("timestamp")

	# attempt to detect typed value
	val_int = None
	val_float = None
	val_bool = None
	val_json = None

	try:
		if isinstance(value, bool):
			val_bool = value
		elif isinstance(value, (int,)) and not isinstance(value, bool):
			val_int = int(value)
		elif isinstance(value, float):
			val_float = float(value)
		elif isinstance(value, str):
			s = value.strip()
			if s.lower() in ("true", "false"):
				val_bool = s.lower() == "true"
			else:
				try:
					val_int = int(s)
				except Exception:
					try:
						val_float = float(s)
					except Exception:
						# try parse JSON arrays/objects
						if (s.startswith("{") or s.startswith("[")):
							try:
								val_json = json.loads(s)
							except Exception:
								val_json = None
		elif isinstance(value, (dict, list)):
			val_json = value
	except Exception:
		# best-effort: leave typed fields None
		pass

	# prepare document for MongoDB
	doc = {
		'node_pk': node.id if node else None,
		'node_id': getattr(node, 'node_id', '') if node else payload.get('node_id', ''),
		'server_endpoint': getattr(node.server, 'endpoint', '') if node and node.server else payload.get('endpoint', ''),
		'value': value,
		'variant_type': str(variant_type),
		'value_int': val_int,
		'value_float': val_float,
		'value_bool': val_bool,
		'value_json': val_json,
		'timestamp': None,
	}
	if ts:
		try:
			# if ts is epoch float seconds
			from datetime import datetime, timezone as _tz
			doc['timestamp'] = datetime.fromtimestamp(float(ts), tz=_tz.utc)
		except Exception:
			doc['timestamp'] = None

	try:
        # We pass 'node' (the Django model instance) for SQLite 
        # and 'doc' (the dictionary) which both backends can use.
		inserted_id = save_opcua_reading(doc, django_node_obj=node)
	except Exception as exc:
		return _error(1104, f"Failed to save reading to configured DB: {exc}", http_status=500)

	return JsonResponse({
        "id": inserted_id, 
        "node": node.id if node else None, 
        "timestamp": doc.get('timestamp').isoformat() if doc.get('timestamp') else None
    }, status=201)
    

@require_http_methods(["GET"])
def export_nodes_xml(request, server_id: int):
    server = get_object_or_404(OPCUAServer, pk=server_id)
    nodes = server.nodes.all()

    # 1. Define Namespaces
    NS_UA = "http://opcfoundation.org/UA/2011/03/UANodeSet.xsd"
    NS_UAX = "http://opcfoundation.org/UA/2008/02/Types.xsd"
    NS_XSI = "http://www.w3.org/2001/XMLSchema-instance"
    
    ET.register_namespace('', NS_UA)
    ET.register_namespace('uax', NS_UAX)
    ET.register_namespace('xsi', NS_XSI)

    root = ET.Element(f"{{{NS_UA}}}UANodeSet")

    # 2. Namespace URIs Section
    ns_uris = ET.SubElement(root, f"{{{NS_UA}}}NamespaceUris")
    # Add your specific project URI
    uri = ET.SubElement(ns_uris, f"{{{NS_UA}}}Uri")
    uri.text = "http://airbus.com/IJT/AFastening" 

    # 3. Models Section (Crucial for the uploaded format)
    models = ET.SubElement(root, f"{{{NS_UA}}}Models")
    model = ET.SubElement(models, f"{{{NS_UA}}}Model", {
        "ModelUri": "http://airbus.com/IJT/AFastening",
        "Version": "1.04",
        "PublicationDate": "2025-09-19T11:03:13Z"
    })
    # Required base model
    ET.SubElement(model, f"{{{NS_UA}}}RequiredModel", {
        "ModelUri": "http://opcfoundation.org/UA/", 
        "Version": "1.05.03"
    })

    # 4. Aliases Section
    aliases = ET.SubElement(root, f"{{{NS_UA}}}Aliases")
    alias_map = {"Boolean": "i=1", "Double": "i=11", "String": "i=12", "HasComponent": "i=47"}
    for name, nid in alias_map.items():
        alias_node = ET.SubElement(aliases, f"{{{NS_UA}}}Alias", {"Alias": name})
        alias_node.text = nid

    # 5. Node Generation logic
    for node in nodes:
        # Determine if it's an Object or Variable based on label or common patterns
        # Folders and PLC objects in your previous script were effectively 'Objects'
        label_text = getattr(node, 'label', str(node.id))
        is_object = "Folder" in label_text or "vPLC" in label_text or "Device" in label_text
        
        tag = f"{{{NS_UA}}}UAObject" if is_object else f"{{{NS_UA}}}UAVariable"
        
        # FIX for 'browse_name' error: 
        # Fallback to 'label' if 'browse_name' doesn't exist, then to 'node_id'
        b_name = getattr(node, 'browse_name', None) or getattr(node, 'label', None) or node.node_id
        
        ua_node = ET.SubElement(root, tag, {
            "NodeId": node.node_id,
            "BrowseName": b_name,
        })
        
        # Safely handle ParentNodeId
        p_id = getattr(node, 'parent_node_id', None) or getattr(node, 'parent_id', "i=85")
        
        # UAVariables need a DataType
        if tag == f"{{{NS_UA}}}UAVariable":
            # Default to 'Double' to avoid the TypeMismatch errors we saw earlier
            ua_node.set("DataType", getattr(node, 'data_type', "Double"))

        # Display Name
        disp = ET.SubElement(ua_node, f"{{{NS_UA}}}DisplayName")
        disp.text = label_text

        # References
        refs = ET.SubElement(ua_node, f"{{{NS_UA}}}References")
        
        # Backwards reference to parent (Hierarchical structure)
        ref_parent = ET.SubElement(refs, f"{{{NS_UA}}}Reference", {
            "ReferenceType": "HasComponent",
            "IsForward": "false"
        })
        ref_parent.text = p_id

        # Type Definition
        ref_type = ET.SubElement(refs, f"{{{NS_UA}}}Reference", {"ReferenceType": "HasTypeDefinition"})
        # i=61 is FolderType/BaseObjectType, i=68 is BaseDataVariableType
        ref_type.text = "i=61" if is_object else "i=68"

	 # Generate XML string
    xml_data = ET.tostring(root, encoding='utf-8', xml_declaration=True)

    response = HttpResponse(xml_data, content_type="application/xml")
    filename = f"nodeset_{server.name.replace(' ', '_')}.xml"
    response['Content-Disposition'] = f'attachment; filename="{filename}"'
    
    return response